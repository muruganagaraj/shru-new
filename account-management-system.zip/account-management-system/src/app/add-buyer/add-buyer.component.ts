import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DialogData } from 'app/buyer-detail/buyer-detail.component';
import { Viewmodel } from './add-buyer.viewmodel';
import { TextPairHelperService } from '../services/text-pair-helper.service';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-add-buyer',
  templateUrl: './add-buyer.component.html',
  styleUrls: ['./add-buyer.component.scss']
})
export class AddBuyerComponent implements OnInit {
  vm: Viewmodel = {};
  ddvalue: TextPair[] = [];
  constructor(
    public dialogRef: MatDialogRef<AddBuyerComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private textPairHelperService: TextPairHelperService,
    private http: HttpClient) {

  }

  ngOnInit() {
    const endpoint = 'https://6d73py636l.execute-api.us-east-1.amazonaws.com/default/EDU_G_GetAll';
    return this.http.get(endpoint).subscribe(
      data => {
        this.getdata(data);
        if (this.dialogRef.componentInstance.data) {
          this.vm = this.convertVotoVM(this.dialogRef.componentInstance.data);
        } else {
          this.vm = {};
        }
      }
    )
  }

  getdata(data: any): any {
    this.ddvalue = this.textPairHelperService.createGSTTextPair(data);
  }

  convertVotoVM(data: any): Viewmodel {
    let modaldata: Viewmodel = {};
    modaldata.BuyerId = data.item.BuyerId;
    modaldata.BuyerCode = data.item.BuyerCode;
    modaldata.GSTId = "10";
    modaldata.Address = data.item.Address;
    modaldata.ContactNo = data.item.ContactNo;
    modaldata.Name = data.item.Name;
    return modaldata;
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}
