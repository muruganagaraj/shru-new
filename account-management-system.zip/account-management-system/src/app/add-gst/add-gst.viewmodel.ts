
export interface viewmodel {
    GSTCode?: number;
    GST?: string;
    Description?: string;
    GSTId?: number;
}