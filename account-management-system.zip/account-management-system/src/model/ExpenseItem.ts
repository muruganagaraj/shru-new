export class ExpenseItem {
    ItemId: string;
    Item: string;
    Price: string;
    Quantity: string;
    Amount: string;
}